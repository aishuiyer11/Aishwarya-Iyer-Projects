#Creating info table
CREATE TABLE `hello`.`info` (
  `cid` INT NOT NULL,
  `name` VARCHAR(45) NOT NULL,
  `age` INT NOT NULL,
  `customer_type` VARCHAR(45) NOT NULL,
  `member` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`cid`));


#Creating room table
ALTER TABLE `hello`.`room` 
ADD COLUMN `event_type` VARCHAR(45) NOT NULL AFTER `cid`,
ADD COLUMN `price` FLOAT NOT NULL AFTER `event_type`,
ADD COLUMN `discount` VARCHAR(45) NOT NULL AFTER `price`,
ADD COLUMN `arrival` DATE NOT NULL AFTER `discount`,
ADD COLUMN `departure` DATE NOT NULL AFTER `arrival`,
CHANGE COLUMN `room_type` `cid` INT NOT NULL ,
ADD INDEX `cid_idx` (`cid` ASC);
;
ALTER TABLE `hello`.`room` 
ADD CONSTRAINT `cid`
  FOREIGN KEY (`cid`)
  REFERENCES `hello`.`info` (`cid`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


#Creating checkout table
CREATE TABLE `hello`.`checkout` (
  `revid` INT NOT NULL,
  `cid` INT NOT NULL,
  `rid` INT NOT NULL,
  `no_participant` INT NOT NULL,
  `pay_type` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`revid`),
  INDEX `cid` (`cid` ASC),
  INDEX `rid` (`rid` ASC));
 
ALTER TABLE `hello`.`checkout` 
ADD CONSTRAINT `cid_fk`
  FOREIGN KEY (`cid`)
  REFERENCES `hello`.`info` (`cid`)
  ON DELETE CASCADE
  ON UPDATE CASCADE,
ADD CONSTRAINT `rid_fk`
  FOREIGN KEY (`rid`)
  REFERENCES `hello`.`room` (`rid`)
  ON DELETE CASCADE
  ON UPDATE CASCADE;


#Question: Find the customer (or customers) who paid the highest room rate in 2017 and is
#also related to at least one more non-primary customer 

#Answer 
SELECT DISTINCT c.cid, MAX(r.price) 
FROM room r, info c
WHERE r.arrival >= '2017-01-01' AND r.departure <= '2017-12-31' 
AND c.customer_type = 'primary' AND c.member = 'yes';

