#!C:/Program Files/Python37/python.exe -u
print("Content-Type:text/html")
print()
import cgi
import pymysql
#cgitb.enable() #for debuggingca
form = cgi.FieldStorage()
uname = form.getvalue('revid')
vname = form.getvalue('cid')
xname = form.getvalue('rid')
yname = form.getvalue('no_participant')
zname = form.getvalue('pay_type')
#print("YOUR RESULT IS",)
#print(revid)
import pymysql

# Open database connection. Notice the autocommit. What is it doing there?
db = pymysql.connect("localhost","root","Mysql_2016","hello", autocommit=True)

# Start a cursor object using cursor() method
cursor = db.cursor()

# Create entry
sql = """INSERT INTO checkout (revid, cid, rid, no_participant, pay_type) VALUES
( %s, %s, %s, %s, %s )"""

cursor.execute(sql,(uname, vname,xname,yname,zname))

# Create query to check if all our heroes are in the table
sql_ret = """SELECT * FROM checkout"""
cursor.execute(sql_ret)
checkout = cursor.fetchall()

#print (info)

# disconnect from server
db.close()