#!C:/Program Files/Python37/python.exe -u
print("Content-Type: text/html")
print()
import cgi,cgitb
cgitb.enable() #for debugging
form = cgi.FieldStorage()
aname = form.getvalue('rid')
bname = form.getvalue('cid')
kname = form.getvalue('room1')
mname = form.getvalue('event')
pname = form.getvalue('price')
dname = form.getvalue('discount')
rname = form.getvalue('arrival')
qname = form.getvalue('departure')
#print("Name of the user is:",name)

import pymysql

# Open database connection. Notice the autocommit. What is it doing there?
db = pymysql.connect("localhost","root","Mysql_2016","hello", autocommit=True)

# Start a cursor object using cursor() method
cursor = db.cursor()

# Create entry
sql = """INSERT INTO room (rid, cid, room_type, event_type, price, discount, arrival, departure) VALUES
( %s, %s, %s, %s, %s, %s, %s, %s)"""

cursor.execute(sql,(aname, bname, kname, mname, pname, dname, rname, qname))

# Create query to check if all our heroes are in the table
sql_ret = """SELECT * FROM room"""
cursor.execute(sql_ret)
room = cursor.fetchall()

#print (info)

# disconnect from server
db.close()