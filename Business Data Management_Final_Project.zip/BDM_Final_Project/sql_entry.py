#!C:/Program Files/Python37/python.exe -u
print("Content-Type: text/html")
print()
import cgi,cgitb
cgitb.enable() #for debugging
form = cgi.FieldStorage()
name = form.getvalue('cid')
fname = form.getvalue('fname')
cname = form.getvalue('age')
oname = form.getvalue('cust')
sname = form.getvalue('grp')
#print("Name of the user is:",name)

import pymysql

# Open database connection. Notice the autocommit. What is it doing there?
db = pymysql.connect("localhost","root","Mysql_2016","hello", autocommit=True)

# Start a cursor object using cursor() method
cursor = db.cursor()

# Create entry
sql = """INSERT INTO info (cid, name, age, customer_type, member) VALUES
( %s, %s, %s, %s, %s)"""

cursor.execute(sql,(name, fname, cname, oname, sname))

# Create query to check if all our heroes are in the table
sql_ret = """SELECT * FROM info"""
cursor.execute(sql_ret)
info = cursor.fetchall()

#print (info)

# disconnect from server
db.close()